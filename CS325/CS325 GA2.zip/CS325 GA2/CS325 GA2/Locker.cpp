#include "Locker.h"



Locker::Locker(int number, TestCase* testCase)
{
	itsCase = testCase;
}

Locker::~Locker()
{
}

void Locker::setHasKey(bool has)
{ 
	hasKey = has;
}

void Locker::setHasBall(bool has)
{
	hasBall = has;
}

void Locker::open()
{
	if (isOpen) return;
	else isOpen = true;
	hasKey = true;
	if (hasBall)
		itsCase->ballFoundAt(thisLocker);
	itsCase->addNewKeyOf(thisLocker);
}
