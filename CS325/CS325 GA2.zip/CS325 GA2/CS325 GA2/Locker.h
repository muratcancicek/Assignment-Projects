#pragma once
#include "TestCase.h"

class Locker
{
public:
	Locker(int number, TestCase* testCase);
	~Locker(); 
	void setHasKey(bool has);
	void setHasBall(bool has);
	void open();
private:
	int thisLocker;
	TestCase* itsCase;
	bool hasKey;
	bool hasBall;
	bool isOpen;
	
};

