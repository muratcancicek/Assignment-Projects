#pragma once
#include <algorithm>
#include <vector>
#include "Locker.h"

class TestCase
{
public: 
	TestCase(char* label, const int lockersNum, std::vector<int>* keys, std::vector<int>* balls);
	~TestCase(); 
	void setExpectedOutput(int output);
	int getOutputOfAlgorithm1();
	int getOutputOfAlgorithm2();
	int getOutputOfAlgorithm3();
	void ballFoundAt(int locker);
	void addNewKeyOf(int locker);
private:
	void checkCorrection(int i);
	char* label; 
	int lockersNumber; 
	int keysNumber; 
	int ballsNumber; 
	std::vector<Locker>* lockers;
	std::vector<int>* givenKeys;
	std::vector<int>* givenBalls;
	int openedLockersNumber;
	int foundBallsNumber;  
	int expectedOutput = -1; // may not be exist
};

