#include <iostream>
#include "TestCase.h"
#include <algorithm>
#include <vector>

using namespace std;

TestCase::TestCase(char* labl, const int lockersNum, vector<int>* keys, vector<int>* balls)
{
	label = labl;
	lockersNumber = lockersNum; 
	givenBalls = balls;
	givenKeys = keys;
	openedLockersNumber = 0; 
	sort(givenKeys->begin(), givenKeys->end());
	sort(givenBalls->begin(), givenBalls->end());
	for (int i = 0; i < lockersNumber; i++)
	{
		(*lockers)[i] = Locker(i, this);
	}
	for (int &key : (*givenKeys)) // May not work on Putty 
	{
		(*lockers)[key].setHasKey(true);
	}
	for (int &ball : (*givenBalls)) // May not work on Putty 
	{
		(*lockers)[ball].setHasBall(true);
	}
}
 
TestCase::~TestCase()
{
	//delete givenKeys;
	//delete givenBalls;
}


void TestCase::setExpectedOutput(int expectedOutput)
{
	this->expectedOutput = expectedOutput;
}

int TestCase::getOutputOfAlgorithm1()
{ 
	// fill here 
	while (!givenBalls->empty())
	{
		 
	}
	checkCorrection(1);
	return openedLockersNumber;
}

int TestCase::getOutputOfAlgorithm2()
{ 
	// fill here
	checkCorrection(2);
	return openedLockersNumber;
}

int TestCase::getOutputOfAlgorithm3()
{ 
	// fill here
	checkCorrection(3);
	return openedLockersNumber;
}


void TestCase::ballFoundAt(int locker)
{
	foundBallsNumber++;
	removeByValue(givenBalls, locker); 
}

void TestCase::checkCorrection(int i)
{
	if (expectedOutput == openedLockersNumber)
		cout << "The algorithm " << i << " for " << label << " worked correctly, output" << openedLockersNumber << endl;
	else if (expectedOutput != -1)
		cout << "The algorithm " << i << " for " << label << " DON'T WORK!, it returns " << openedLockersNumber << endl;

}

void TestCase::addNewKeyOf(int key)
{
	if (contains(givenBalls, key)) return;
	givenKeys->push_back(key); 
	sort(givenKeys->begin(), givenKeys->end());
}

bool contains(vector<int>* v, int element)
{
	return find(v->begin(), v->end(), element) == v->end();
}

void removeByValue(vector<int>* vec, int value)
{
	vec->erase(remove(vec->begin(), vec->end(), value), vec->end());
}