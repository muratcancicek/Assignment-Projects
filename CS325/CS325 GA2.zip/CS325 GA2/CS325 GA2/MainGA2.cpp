#include <iostream>
#include <fstream>
#include <sstream>  
#include <string>  
#include <vector>
#include <algorithm>
#include <ctime>
#include "TestCase.h"

typedef int(*algorithm)(int[], int); 

using namespace std;

double analyseAlgRunningTime(algorithm alg, const char* algName, int arr[], int lenOfArr)
{
	//Time stamp before the computations
	clock_t start = clock();
	/* Computations to be measured */
	int bestSum = (*alg)(arr, lenOfArr);
	// Time stamp after the computations
	clock_t end = clock();
	double cpu_time = (double)(end - start) / CLOCKS_PER_SEC;
	cout << algName << " is ran in " << cpu_time << " seconds. \n";
	return cpu_time; 
}

ifstream openIStream(const char* fileName)
{
	ifstream testFile(fileName);
	if (testFile.fail())
	{
		cout << "The file could not be opened!\n";
		exit(1); // 0 � nrormal exit, non zero � some error
	}
	return testFile;
}

vector<int>* readIntArrayFrom(stringstream* line)
{
	vector<int>* intCollector = new vector<int>();
	int nextInt;
	while ((*line) >> nextInt)
	{
		intCollector->push_back(nextInt);
	}
	return &(*intCollector);
}
// the dirtiest method I have ever written
vector<TestCase> readTestCasesFrom(const char* fileName) 
{ 
	ifstream testFile = openIStream(fileName); 
	string l = "";
	vector<TestCase> testCases;
	int testCaseRow = 0;
	int lockersNumber;
	int keysNumber;
	int ballsNumber;
	vector<int>* givenKeys = NULL;
	vector<int>* givenBalls = NULL;
	int expectedOutput = -1; // check later if exists  
	bool isCaseOnCache = false;  // For the last case, we need check isCaseOnCache? at the end of file
	while (getline(testFile, l) || isCaseOnCache)
	{
		if (l.empty() || isCaseOnCache)
		{
			if (isCaseOnCache) // There are enough inputs
			{ 
				char* label = const_cast<char*>((string(fileName) + " T" +to_string(testCases.size() + 1)).c_str());
				TestCase* testCase = new TestCase(label,lockersNumber, keysNumber, ballsNumber, givenKeys, givenBalls);
				if (testCaseRow >= 5) // if exists
					testCase->setExpectedOutput(expectedOutput);
				testCases.push_back(*testCase);
				lockersNumber = 0;
				isCaseOnCache = false;
			} 
			if(l.empty())
				testCaseRow = 0;
			continue;
		} 
		isCaseOnCache = false;
		testCaseRow++;
		stringstream line(l);
		switch (testCaseRow)
		{
		// case 1: INPUT TITLE
		case 2: // N M T
			line >> lockersNumber;
			line >> keysNumber;
			line >> ballsNumber;
			break;
		case 3: // M key tags
			givenKeys = readIntArrayFrom(&line);  
			break;
		case 4: // T ball tags
			givenBalls = readIntArrayFrom(&line);
			getline(testFile, l); // for case duplication bug and OUTPUT TITLE
			isCaseOnCache = l.empty(); 
			break;
		case 5: // expectedOutput
			line >> expectedOutput; 
			isCaseOnCache = true;
		default:
			break;
		} 
	}
	testFile.close();
	return testCases;
}

vector<TestCase> readAllTestCases()
{
	vector<TestCase> allCases; 
	vector<TestCase> dpCases = readTestCasesFrom("../dp.txt");
	vector<TestCase> dp_set1Cases = readTestCasesFrom("../dp_set1.txt");
	vector<TestCase> dp_set2Cases = readTestCasesFrom("../dp_set2.txt");
	allCases.insert(allCases.end(), dpCases.begin(), dpCases.end()); // Merging two vector
	allCases.insert(allCases.end(), dp_set1Cases.begin(), dp_set1Cases.end()); // Merging two vector
	allCases.insert(allCases.end(), dp_set2Cases.begin(), dp_set2Cases.end()); // Merging two vector 
	return allCases;
}
int main()
{
	vector<TestCase> allCases = readAllTestCases();
	for (int i = 0; i < allCases.size(); i++)
	{
		allCases[i].getOutputOfAlgorithm1();
	}
	return 0;
}