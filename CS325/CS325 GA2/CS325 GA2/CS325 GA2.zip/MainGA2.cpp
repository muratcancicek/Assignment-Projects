#include <string> 
#include <iostream> 
#include <fstream> 
#include <sstream>  
#include <vector>
#include <algorithm>
#include <ctime>
#include "TestCase.h"

typedef int(*algorithm)(int[], int); 

using namespace std;

double analyseAlgRunningTime(algorithm alg, const char* algName, int arr[], int lenOfArr)
{
	//Time stamp before the computations
	clock_t start = clock();
	/* Computations to be measured */
	int bestSum = (*alg)(arr, lenOfArr);
	// Time stamp after the computations
	clock_t end = clock();
	double cpu_time = (double)(end - start) / CLOCKS_PER_SEC;
	cout << algName << " is ran in " << cpu_time << " seconds. \n";
	return cpu_time; 
}
 
// the dirtiest method I have ever written
vector<int>* readIntVectorFromLine(string l)
{  
	vector<int>* v = new vector<int>();
	int nextInt;
	stringstream line(l);
	while ((line) >> nextInt)
	{
		v->push_back(nextInt-1);
	} 
	sort(v->begin(), v->end());
	return v;
}

std::istream& safeGetline(std::istream& is, std::string& t)
{
	t.clear();

	// The characters in the stream are read one-by-one using a std::streambuf.
	// That is faster than reading them one-by-one using the std::istream.
	// Code that uses streambuf this way must be guarded by a sentry object.
	// The sentry object performs various tasks,
	// such as thread synchronization and updating the stream state.

	std::istream::sentry se(is, true);
	std::streambuf* sb = is.rdbuf();

	for (;;) {
		int c = sb->sbumpc();
		switch (c) {
		case '\n':
			return is;
		case '\r':
			if (sb->sgetc() == '\n')
				sb->sbumpc();
			return is;
		case EOF:
			// Also handle the case when the last line has no line ending
			if (t.empty())
				is.setstate(std::ios::eofbit);
			return is;
		default:
			t += (char)c;
		}
	}
}

string l = "";
TestCase* readACase(ifstream* testFile)
{
	string label = "";
	int lockersNumber = -9;
	int keysNumber = -9;
	int ballsNumber = -9;
	vector<int>* givenKeys = NULL;
	vector<int>* givenBalls = NULL;
	int expectedOutput = -1; // check later if exists
	//safeGetline((*testFile), l); 
	while (l.empty())  
		safeGetline((*testFile), l); 
	label = l; 
	safeGetline((*testFile), l);  stringstream line(l);	 // N M T 
	line >> lockersNumber >> keysNumber >> ballsNumber;
	safeGetline((*testFile), l);
	givenKeys = readIntVectorFromLine(l);	// M key tags
	safeGetline((*testFile), l);
	givenBalls = readIntVectorFromLine(l);	// T ball tags  
	TestCase* testCase = new TestCase(label, lockersNumber, givenKeys, givenBalls);
	safeGetline((*testFile), l); // OUTPUT TITLE OR BLANK 
	if (!l.empty())
	{
		safeGetline((*testFile), l); stringstream line(l); // EXPECTED OUTPUT 
		line >> expectedOutput;
		testCase->setExpectedOutput(expectedOutput);
	}
	//cout << endl;
	return testCase;
}
 
vector<TestCase*> readTestCasesFrom(const char* fileName)
{ 
	ifstream testFile(fileName);
	if (testFile.fail())
	{
		cout << "The file could not be opened!\n";
		exit(1); // 0 � nrormal exit, non zero � some error
	}  
	vector<TestCase*> testCases; 
	int counter = 1;  
	while (!(safeGetline((testFile), l)).eof())
	{  
			testCases.push_back(readACase(&testFile)); 
	} 
	testFile.close();
	return testCases;
}

vector<TestCase*> readAllTestCases()
{
	vector<TestCase*> allCases;  
	vector<TestCase*> dpCases = readTestCasesFrom("dp.txt");
	//vector<TestCase*> dp_set1Cases = readTestCasesFrom("dp_set1.txt");
	//vector<TestCase*> dp_set2Cases = readTestCasesFrom("dp_set2.txt");
	allCases.insert(allCases.end(), dpCases.begin(), dpCases.end()); // Merging two vector
	//allCases.insert(allCases.end(), dp_set1Cases.begin(), dp_set1Cases.end()); // Merging two vector
	//allCases.insert(allCases.end(), dp_set2Cases.begin(), dp_set2Cases.end()); // Merging two vector 
	return allCases;
}

void testAlgorithm(int algorithm)
{
	vector<TestCase*> allCases = readAllTestCases();
	cout << "################################# ALGORITHM " << algorithm << " ##################################" << endl;
	for (int i = 0; i < allCases.size(); i++)
	{
		if(algorithm == 1)
			allCases[i]->getOutputOfAlgorithm1();
		else if (algorithm == 2)
			allCases[i]->getOutputOfAlgorithm2();
		else if (algorithm == 3)
			allCases[i]->getOutputOfAlgorithm3();
	} 
	cout << endl << "################################################################################" << endl << endl;
}
int main()
{
	testAlgorithm(1);
	testAlgorithm(2);
	return 0;
}