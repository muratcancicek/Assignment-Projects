#include <iostream>
#include <algorithm>
#include <vector>
#include "TestCase.h"
#include "Locker.h"
#include <string>

using namespace std;

TestCase::TestCase(string labl, const int lockersNum, vector<int>* givenKeys, vector<int>* givenBalls)
{  
	label = labl;
	lockersNumber = lockersNum; 
	balls = givenBalls;
	keys = givenKeys;
	expectedOutput = -1;
	openedLockersNumber = 0; 
	for (int i = 0; i < lockersNumber; i++)
	{
		lockers.push_back(new Locker(i));
	}
	for (int k = 0; k < keys->size(); k++) 
	{
		lockers[(*keys)[k]]->setHasKey(true);
	}
	for (int b = 0; b < balls->size(); b++) 
	{
		lockers[(*balls)[b]]->setHasBall(true);
	}
}
 
TestCase::~TestCase()
{
	delete keys;
	delete balls;
	//for (Locker* locker : lockers) // does this work ?
	//{
	//	delete locker;
	//}
}


void TestCase::setExpectedOutput(int expectedOutput)
{
	this->expectedOutput = expectedOutput;
}

bool contains(vector<int>* v, int element)
{
	return find(v->begin(), v->end(), element) != v->end();
}

void removeByValue(vector<int>* vec, int value)
{
	vec->erase(remove(vec->begin(), vec->end(), value), vec->end());
}
int lockerDistance(int a, int b)
{
	return (a - b) >= 0 ? (a - b) : (b - a);
}


void TestCase::ballFoundAt(int locker)
{
	foundBallsNumber++;
	removeByValue(balls, locker); 
}


void TestCase::addNewKeyOf(int key)
{
	if (contains(keys, key)) return;
	lockers[key]->setHasKey(true);
	keys->push_back(key);
	sort(keys->begin(), keys->end());
}

void TestCase::open(int locker)
{
	if (lockers[locker]->isOpen())
		return;
	else
		lockers[locker]->setOpen(true);
	if (lockers[locker]->hasABall())
		ballFoundAt(locker);
	if ((locker - 1) >= 0)
	{
		addNewKeyOf(locker - 1);
	}
	if ((locker + 1 < lockers.size()))
	{
		addNewKeyOf(locker + 1);
	}
	openedLockersNumber++; 
}

void TestCase::openNKeepKey(int locker)
{
	if (lockers[locker]->isOpen())
		return;
	else
	{
		open(locker);
		addNewKeyOf(locker);
	}
		
}

void TestCase::openLockersFromTo(int from, int to)
{
	if (from < to)
	{
		for (int locker = from; locker < to; locker++) // GO RIGHT
		{
			open(locker);
		}
	} 
	else
	{
		for (int locker = from; locker > to; locker--) // GO LEFT
		{
			open(locker);
		}
	}
	openNKeepKey(to);
}

// ALGORITHM X 

void TestCase::findBestBall()
{
	// [B, K, distance] but start with left side
	int minDistance = lockerDistance(balls->front(), keys->front());
	int b[2] = { keys->front(), balls->front() };
	int* bestPair = b;
	if (minDistance == 0)
	{
		openNKeepKey(bestPair[1]);
		return;
	}
	for (int b = 0; b < balls->size(); b++)
	{
		for (int k = 0; k < keys->size(); k++)
		{
			int tempDistance = lockerDistance((*balls)[b], (*keys)[k]); 
			if (tempDistance == 0)
			{
				openNKeepKey((*keys)[k]);
				return;
			}
			else if (tempDistance < minDistance)
			{
				minDistance = tempDistance;
				int tempPair[2] = { (*keys)[k], (*balls)[b] };
				bestPair = tempPair;
			}
		}
	}
	openLockersFromTo(bestPair[0], bestPair[1]);	
}


int TestCase::getOutputOfAlgorithm1()
{ 
	 //fill here 
	while (!balls->empty())
	{ 
		findBestBall();
	}
	checkCorrection(1);
	return openedLockersNumber;
}

// ALGORITHM Y


void TestCase::findRightMostBall()
{
	int rightMostBall = balls->back(); 
	int rightMostKey = keys->back();
	if (rightMostBall > rightMostKey )
	{
		openLockersFromTo(rightMostKey, rightMostBall); 
	}
	else if (keys->size() == 1)
	{
		openLockersFromTo(rightMostKey, rightMostBall);
		keys->pop_back();
	}
	else
	{
		int secondRightMostKey = (*keys)[keys->size() - 2];
		while (rightMostBall < secondRightMostKey)
		{
			keys->pop_back(); // delete current RightMostKey 
			rightMostKey = secondRightMostKey;
			if (keys->size() == 1)
			{
				openLockersFromTo(rightMostKey, rightMostBall); 
				return;
			}
			secondRightMostKey = (*keys)[keys->size() - 2];
		}
		int rightDistance = lockerDistance(rightMostKey, rightMostBall);
		int leftDistance = lockerDistance(secondRightMostKey, rightMostBall);
		if (leftDistance <= rightDistance)
		{ 
			keys->pop_back(); // delete current RightMostKey
			openLockersFromTo(secondRightMostKey, rightMostBall); 
			keys->pop_back();
		}
		else
		{
			keys->pop_back(); // delete current RightMostKey
			openLockersFromTo(rightMostKey, rightMostBall);
			keys->pop_back();
		}

	}
}

int TestCase::getOutputOfAlgorithm2()
{ 
	// fill here
	
	while (!balls->empty())
	{
		findRightMostBall();
	}
	checkCorrection(2);
	return openedLockersNumber;
}

int TestCase::getOutputOfAlgorithm3()
{ 
	// fill here
	checkCorrection(3);
	return openedLockersNumber;
}

void TestCase::checkCorrection(int i)
{
	if (expectedOutput == openedLockersNumber)
		cout << "The algorithm " << i << " for " << label << " worked correctly, output = " << openedLockersNumber << endl;
	else if (expectedOutput != -1)
		cout << "The algorithm " << i << " for " << label << " DON'T WORK!, it returns " 
		<< openedLockersNumber << " instead of " << expectedOutput << endl;

}
