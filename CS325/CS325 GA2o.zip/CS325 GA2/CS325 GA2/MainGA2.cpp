#include <iostream>
#include <fstream>
#include <sstream>  
#include <string>  
#include <vector>
#include <ctime>
#include "TestCase.h"

typedef int(*algorithm)(int[], int); 

using namespace std;

double analyseAlgRunningTime(algorithm alg, const char* algName, int arr[], int lenOfArr)
{
	//Time stamp before the computations
	clock_t start = clock();
	/* Computations to be measured */
	int bestSum = (*alg)(arr, lenOfArr);
	// Time stamp after the computations
	clock_t end = clock();
	double cpu_time = (double)(end - start) / CLOCKS_PER_SEC;
	cout << algName << " is ran in " << cpu_time << " seconds. \n";
	return cpu_time; 
}

ifstream openIStream(const char* fileName)
{
	ifstream testFile(fileName);
	if (testFile.fail())
	{
		cout << "The file could not be opened!\n";
		exit(1); // 0 � nrormal exit, non zero � some error
	}
	return testFile;
}

vector<int> readIntArrayFrom(stringstream* line)
{
	vector<int> intCollector;
	int nextInt;
	while ((*line) >> nextInt)
	{
		intCollector.push_back(nextInt);
	}
	return intCollector;
}
// the dirtiest method I have ever written
vector<TestCase> readTestCasesFrom(const char* fileName) 
{ 
	ifstream testFile = openIStream(fileName); 
	string l = "";
	vector<TestCase> testCases;
	int testCaseRow = 0;
	int lockersNumber;
	int keysNumber;
	int ballsNumber;
	vector<int> givenKeys;
	vector<int> givenBalls;
	int expectedOutput = -1; // check later if exists  
	bool isCaseOnCache = false;  // For the last case, we need check isCaseOnCache? at the end of file
	while (getline(testFile, l) || isCaseOnCache)
	{
		if (l.empty() || isCaseOnCache)
		{
			if (testCaseRow >= 3) // There are enough inputs
			{
				int* keys = givenKeys.data();
				int* balls = givenKeys.data(); 
				TestCase* testCase = new TestCase("",lockersNumber, keysNumber, ballsNumber, keys, balls);
				if (expectedOutput != -1) // if exists
					testCase->setExpectedOutput(expectedOutput);
				testCases.push_back(*testCase);
				lockersNumber = 0;isCaseOnCache = false;
			} 
			testCaseRow = 0;
			continue;
		} isCaseOnCache = false;
		testCaseRow++;
		stringstream line(l);
		switch (testCaseRow)
		{
		// case 1: INPUT TITLE
		case 2: // N M T
			line >> lockersNumber;
			line >> keysNumber;
			line >> ballsNumber;
			break;
		case 3: // M key tags
			givenKeys = readIntArrayFrom(&line); 
			break;
		case 4: // T ball tags
			givenBalls = readIntArrayFrom(&line);
			isCaseOnCache = true;
			break;
		// case 5: OUTPUT TITLE
		case 6: // expectedOutput
			line >> expectedOutput;
			isCaseOnCache = true;
		default:
			break;
		} 
	}
	testFile.close();
	return testCases;
}

vector<TestCase> readAllTestCases()
{
	vector<TestCase> allCases; 
	vector<TestCase> dpCases = readTestCasesFrom("../dp.txt");
	vector<TestCase> dp_set1Cases = readTestCasesFrom("../dp_set1.txt");
	vector<TestCase> dp_set2Cases = readTestCasesFrom("../dp_set2.txt");
	allCases.insert(allCases.end(), dpCases.begin(), dpCases.end()); // Merging two vector
	allCases.insert(allCases.end(), dp_set1Cases.begin(), dp_set1Cases.end()); // Merging two vector
	allCases.insert(allCases.end(), dp_set2Cases.begin(), dp_set2Cases.end()); // Merging two vector 
	return allCases;
}
int main()
{
	vector<TestCase> allCases = readAllTestCases();
	return 0;
}