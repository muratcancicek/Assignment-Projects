#pragma once
class TestCase
{
public:
	TestCase(char* label, int lockersNum, int keysNum, int ballsNum, int* keys, int* balls);
	~TestCase(); 
	void setExpectedOutput(int output);
	int getOutputOfAlgorithm1();
	int getOutputOfAlgorithm2();
	int getOutputOfAlgorithm3();
private:
	void checkCorrection(int i, int output);
	char* label;
	int lockersNumber; 
	int keysNumber; 
	int ballsNumber;
	int expectedOutput = -1; // may not be exist
	int* givenKeys;
	int* givenBalls; 
};

