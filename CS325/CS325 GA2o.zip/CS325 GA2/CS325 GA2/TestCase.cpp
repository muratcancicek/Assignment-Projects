#include <iostream>
#include "TestCase.h"


TestCase::TestCase(char* labl, int lockersNum, int keysNum, int ballsNum, int* keys, int* balls)
{
	label = label;
	lockersNumber = lockersNum;
	keysNumber = keysNum;
	ballsNumber = ballsNum;
	givenBalls = balls;
	givenKeys = keys;
}
 
TestCase::~TestCase()
{
	//delete givenKeys;
	//delete givenBalls;
}


void TestCase::setExpectedOutput(int expectedOutput)
{
	this->expectedOutput = expectedOutput;
}

int TestCase::getOutputOfAlgorithm1()
{
	int output;
	// fill here
	checkCorrection(1, output);
	return 0;
}

int TestCase::getOutputOfAlgorithm2()
{
	int output;
	// fill here
	checkCorrection(2, output);
	return 0;
}

int TestCase::getOutputOfAlgorithm3()
{
	int output;
	// fill here
	checkCorrection(3, output);
	return 0;
}

void TestCase::checkCorrection(int i, int output)
{
	if (expectedOutput == output)
		std::cout << "The algorithm " << i << " worked correctly, the output " << output << std::endl;
	else if (expectedOutput != -1)
		std::cout << "The algorithm " << i << " WRONG!, it returns " << output << std::endl;

}

