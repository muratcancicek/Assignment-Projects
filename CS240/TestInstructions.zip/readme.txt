Move program.v in the directory of your project.
Run ISIM and add memory object to right panel.
Select memory and set radix to signed decimal (important for negative results)
DO NOT forget to click run All button or your simulation may not complete tests.

Compare addresses and values below (or look at screenshot)

48: 4294967294 (-2 if signed decimal is selected)
49: 4294967295 (-1 if signed decimal is selected)
50: 0
51: 1
52: 2
53: 3
54: 4
55: 5
56: 6
57: 7
58: 8
59: 1
60: 0
61: 9
62: 10
63: 11